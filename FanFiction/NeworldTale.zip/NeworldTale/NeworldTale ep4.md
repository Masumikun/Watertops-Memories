---
date created: Tuesday, 30th ✦ Dec┆2025 ➣ 22▫32▫19
date modified: Tuesday, 30th ✦ Dec┆2025 ➣ 22▫32▫19
tags:
  - NeworldTale
status:
  - ⚙️ Desenvolvimento
---

[[NeworldTale ep3]]

# Perdas & Guerras
## Medo Agoniante
- *Era **18XX** à **20XX** *

Os humanos eram mais **calmos** e **tranquilos** depois de *selarem* os monstro, mas lenda não saiu suas cabeças, contavam sobre **Criaturas** horrendas como lenda de serem.<br>
Quando foi um tempo através de conceitos de lendas por trás de **Asriel**, porém a sociedade usou que era aparência de **Asgore** e poderes proibido de **absorve** almas humanas sendo uma lenda para perturbar a mente dos humanos por muitos tempo.

### FrozenTime
- *Era **18XX** à **20XX** *

Quando caiu a criança diante a paciência sobre com monstro que era visto como nada seu comportamento era sempre diante de atacar seus inimigos com danos mágicos congelamento, a ruínas era como pedra de era fria, mas parecia um gelo que tomava tudo de forma passiva e vagarosa, a <span style="color:rgb(0, 255, 255)">Akura Toshi</span> era uma pessoa calma, sabia quando atacar seus inimigos no momento exato, quando se deu conta Toriel atingiu seus **medos** e **crenças**

Quando **Akura** se aproximou de um refúgio, ficou naquele local, como própria fuga de suas intenções próprias, ainda as **crenças** dos ancestrais abalaram suas forças de vontades.

----

### Honrado De Força
- *Pós era **18XX** à **20XX** *

Quando caiu a criança que era grande conhecido lutador dos punhos massivo era grande escolhido para acha uma criança perdida que acreditam que dizia na **carta**

- ✉️ **Carta**
	- [i] Nossa grande ==filha mágica sempre== chamamos de floco de neve, muita vezes apelidamos de floco abraçador.<br><br>
	Houve um ==desaparecimento nossa época== pela grande demanda de procura de crianças era definidas ***salvadoras*** ou ***jogadas*** ao limbo para um ==deus chamado Rumaryn Hapon==<br><br>
	==As das ***salvação***== era mortas para mantemos vivos enquanto as dos ==***limbo*** era definidas== como trazedores de **decadência**<br><br>
	Se trazerem a nós, iremos pagar uma recompensa<br><br><br>
	PS: ==Rasurado por causa do tempo==

<br>

- 📜 ***Narrador***
	Tudo está em destacado são partes do texto rasurado por causa do tempo que carta foi se afetado

Quando desceu os monstro que enfrentaram diante um humano nada **calmo** ainda mais que era **agressivo** em seus ataques pareciam rochas do que antigos **gelos** e **abraçadores**, enquanto Toriel o viu pela primeiras vezes, tentou ensinar usa menos a **porradaria**, mas ele era destemido acabou derrubado Toriel, quando saiu deu de cara com povo do gelo, mas claramente alguém acabou o avistando...

## Honrado Na Coragem
Papyrus ➣ *Risada característica*